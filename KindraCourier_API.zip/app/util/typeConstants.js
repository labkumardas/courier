const typeConstants = {
    jobType: {
      outJob:'OUT_JOB',
      inJob:'IN_JOB' 
    },
    createrType: {
        driver:'driver',
        user:'user' 
    } 
  };
  
  export default typeConstants;
  